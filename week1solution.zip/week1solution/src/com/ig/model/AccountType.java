package com.ig.model;

public enum AccountType {
	SAVINGS,
	CURRENT
}
