package com.ig.ui;

import com.ig.exception.AccountNotFoundException;
import com.ig.exception.InsufficientFundsException;
import com.ig.exception.InvalidAmountException;
import com.ig.exception.LowBalanceException;
import com.ig.model.Account;
import com.ig.model.AccountType;
import com.ig.service.AccountService;

public class AccountTest {
	public static void main(String[] args) throws InvalidAmountException {
        AccountService service = new AccountService();
        try {
        	 Account acc = new Account(123, "Phantom", AccountType.SAVINGS, 900f);
        	
        }catch (LowBalanceException e) {
			// TODO: handle exception
        	System.out.println(e.getMessage());
		}
        try {
        	Account acc0 = new  Account(456, "Dracula", AccountType.CURRENT, 4999.99f);
        }
        catch (LowBalanceException e) {
			System.out.println(e.getMessage());
		}
        try {
            Account acc1 = new Account(123, "Phantom", AccountType.SAVINGS, 1500f);
            Account acc2 = new Account(456, "Dracula", AccountType.CURRENT, 6000f);
            Account acc3 = new Account(789, "DarkKnight", AccountType.SAVINGS, 2000f);
            Account acc4 = new Account(101, "BatMan", AccountType.CURRENT, 7000f);
            Account acc5 = new Account(112, "Pavan Sai", AccountType.SAVINGS, 9999999f);
            service.addAccount(acc1);
            service.addAccount(acc2);
            service.addAccount(acc3);
            service.addAccount(acc4);
            service.addAccount(acc5);
            service.deposit(123, 500f);
            service.withdraw(456, 1000f);
            System.out.println("Balance for account 789: " + service.getBalance(789));
            try {
                if (service.isValidAccount(123)) {
                    System.out.println("Account 123 Number is valid.");
                }
            } catch (AccountNotFoundException e) {
                System.out.println(e.getMessage());
            }
            try {
                service.withdraw(123, 4500f);
            } catch (InsufficientFundsException e) {
                System.out.println(e.getMessage());
            } catch (InvalidAmountException e) {
                System.out.println(e.getMessage());
            }
            try {
                service.isValidAccount(999);
            } catch (AccountNotFoundException e) {
                System.out.println(e.getMessage());
            }
            service.withdraw(456, -988f);
        } catch (LowBalanceException | InvalidAmountException | AccountNotFoundException | InsufficientFundsException e) {
            System.out.println(e.getMessage());
        }
    }
}
