package com.ig.model;

import com.ig.exception.InvalidAmountException;
import com.ig.exception.LowBalanceException;

public class Account {
	Integer accNumber;
	String custName;
	AccountType type;
	Float balance;
	public Integer getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(Integer accNumber) {
		this.accNumber = accNumber;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public AccountType getType() {
		return type;
	}
	public void setType(AccountType type) {
		this.type = type;
	}
	public Float getBalance() {
		return balance;
	}
	public void setBalance(Float balance) {
		this.balance = balance;
	}
	
	public Account(Integer accNumber, String custName, AccountType type, Float balance) throws InvalidAmountException,LowBalanceException {
		super();
		this.accNumber = accNumber;
		this.custName = custName;
		this.type = type;
		this.balance = balance;
		if (balance<0) {
			throw new InvalidAmountException("Balance cannot be negative Integers");
		}
		if(type==AccountType.SAVINGS && balance <1000) {
			throw new LowBalanceException("Balance must be >=1000 for Intial Savings Account Deposit");
		}
		if(type==AccountType.CURRENT && balance<5000) {
			throw new LowBalanceException("Balance must be >=5000 for Intial Current Account Deposit");
		}
	}
	@Override
	public String toString() {
		return "Account [accNumber=" + accNumber + ", custName=" + custName + ", type=" + type + ", balance=" + balance
				+ "]";
	}
	
}
