package com.ig.service;

import java.util.ArrayList;
import java.util.List;

import com.ig.exception.AccountNotFoundException;
import com.ig.exception.InsufficientFundsException;
import com.ig.exception.InvalidAmountException;
import com.ig.model.Account;
import com.ig.model.AccountType;

public class AccountService {
	List<Account> accounts = new ArrayList<>();
	
	 public boolean isValidAccount(int acNumber) throws AccountNotFoundException {
	        for (Account account : accounts) {
	            if (account.getAccNumber().equals(acNumber)) {
	                return true;
	            }
	        }
	        throw new AccountNotFoundException("Account with number " + acNumber + " not found.");
	    }
	   public void deposit(int acNumber, float amt) throws InvalidAmountException, AccountNotFoundException {
	        if (amt <= 0) {
	            throw new InvalidAmountException("Deposit amount must be positive.");
	        }
	        Account account = getAccountByNumber(acNumber);
	        account.setBalance(account.getBalance() + amt);
	        System.out.println("Deposit successful. New balance: " + account.getBalance());
	    }
	   public void withdraw(int acNumber, float amt) throws InvalidAmountException, InsufficientFundsException, AccountNotFoundException {
	        if (amt < 500) {
	            throw new InvalidAmountException("Minimum withdrawal amount is 500.");
	        }
	        Account account = getAccountByNumber(acNumber);
	        AccountType accountType = account.getType();
	        float currentBalance = account.getBalance();

	        float minBalance = (accountType == AccountType.SAVINGS) ? 1000 : 5000;

	        if (currentBalance - amt < minBalance) {
	            throw new InsufficientFundsException("Insufficient funds. Minimum balance of " + minBalance + " must be maintained.");
	        }
	        account.setBalance(currentBalance - amt);
	        System.out.println("Withdrawal successful. New balance: " + account.getBalance());
	    }
	   public float getBalance(int acNumber) throws AccountNotFoundException {
	        Account account = getAccountByNumber(acNumber);
	        return account.getBalance();
	    }
	   Account getAccountByNumber(int acNumber) throws AccountNotFoundException {
	        for (Account account : accounts) {
	            if (account.getAccNumber().equals(acNumber)) {
	                return account;
	            }
	        }
	        throw new AccountNotFoundException("Account with number " + acNumber + " not found.");
	    }

	    public void addAccount(Account account) {
	        accounts.add(account);
	    }

}
